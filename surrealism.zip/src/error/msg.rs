//! Error message
//! ```txt
//! @author:syf20020816@Outlook.com
//! @date:2023/8/21
//! @version:0.0.1
//! @description:
//! ```

pub const CONFIG_NOT_FOUND_ERROR:&str = "Could not find the config file : `Surrealism.toml` or `Surrealism.json`!\nYou must make config file : `Surrealism.toml` or `Surrealism.json` under the config dir : `/ ` , `/templates/` , `/configs/`";



